create table comment
(
    dtype              varchar(31)  not null,
    comment_id         bigint auto_increment
        primary key,
    created_date       datetime     null,
    last_modified_date datetime     null,
    content            varchar(255) null,
    member_member_id   bigint       null,
    constraint FKt9506vjfa0ht9b564lv2ya13o
        foreign key (member_member_id) references members (member_id)
);

