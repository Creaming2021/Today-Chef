create table members
(
    member_id          bigint auto_increment
        primary key,
    created_date       datetime     null,
    last_modified_date datetime     null,
    address            varchar(255) null,
    name               varchar(255) null,
    phone_number       varchar(255) null,
    zone_code          varchar(255) null,
    email              varchar(255) null,
    kakao_id           varchar(255) null,
    nickname           varchar(255) null,
    phone              varchar(255) null,
    profile_image      varchar(255) null
);

INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (6, '2021-05-18 07:46:34', '2021-05-18 07:46:34', null, null, null, null, 'ekdbs628@gmail.com', '1000', '다윤짱', '01029339944', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (7, '2021-05-18 07:47:02', '2021-05-19 01:27:02', '', null, null, null, 'wlsdhr0831@naver.com', '1000', '내가 바로 요리왕', '010-7846-7318', 'https://d6sx5vd3amky9.cloudfront.net/20210519012702392_4.JPG');
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (8, '2021-05-18 07:49:34', '2021-05-19 01:06:16', '', null, null, null, 'melon@melon.com', '1', '멜론', '010-3759-2194', 'https://d6sx5vd3amky9.cloudfront.net/20210519010616593_다운로드.png');
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (9, '2021-05-19 01:28:23', '2021-05-19 01:28:23', null, null, null, null, 'spicy@naver.com', '1000', '맵찔이', '010-7651-7394', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (10, '2021-05-19 01:31:19', '2021-05-19 01:55:22', '', null, null, null, 'dduck@naver.com', '1000', '떡보단 어묵', '010-6492-4138', 'https://d6sx5vd3amky9.cloudfront.net/20210519015522144_5.jpg');
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (11, '2021-05-19 08:09:22', '2021-05-19 08:12:10', '', null, null, null, 'eric99kr@naver.com', '1738040570', '나는병훈', '010-1234-4678', 'https://d6sx5vd3amky9.cloudfront.net/20210519171210797_자료구조론.jpg');
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (12, '2021-05-19 18:08:30', '2021-05-19 18:08:30', null, null, null, null, 'chat@gmail.com', '1000', '채팅프로필테스트', '429834734', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (13, '2021-05-19 18:10:45', '2021-05-19 18:10:45', null, null, null, null, 'chattype@gmail.com', '1000', '채팅프사타입', '23424242', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (14, '2021-05-19 18:13:22', '2021-05-19 18:13:22', null, null, null, null, 'chattest@gmail.com', '1000', '채팅ㅌㅅㅌ', '347289478', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (15, '2021-05-19 18:18:17', '2021-05-19 18:18:17', null, null, null, null, 'ssafy1@naver.com', '1000000000', '김싸피', '01000000000', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (16, '2021-05-19 18:21:55', '2021-05-19 18:21:55', null, null, null, null, 'chatpf@gmail.com', '1000', '채팅프사', '45431341', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (17, '2021-05-19 18:32:41', '2021-05-20 05:43:02', '', null, null, null, 'ekdbs628@next.com', '1000', '채팅마지막', '3244234', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (19, '2021-05-20 01:18:24', '2021-05-20 01:18:24', null, null, null, null, 'www@nav.com', '1726428009', '334', '010-1123-4445', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (20, '2021-05-20 02:22:54', '2021-05-20 02:22:54', null, null, null, null, 'ssafy2@naver.com', '1000000001', '호머심슨', '010-1234-1234', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (21, '2021-05-20 03:05:50', '2021-05-20 03:05:50', null, null, null, null, 'ssafy3@naver.com', '1000000003', '스페인장인', '010-1234-1234', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (22, '2021-05-20 06:05:47', '2021-05-20 06:05:47', null, null, null, null, 'imelon@naver.com', '1710463963', '나는 멜론', '010-4935-7158', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (23, '2021-05-20 06:15:45', '2021-05-20 06:15:45', null, null, null, null, 'ekdbs628@naver.com', '1000', '고기좋아❤', '01052132298', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (24, '2021-05-20 11:09:27', '2021-05-20 11:09:27', null, null, null, null, 'test@test.com', '1727136218', '치킨전도사
', '010-1111-1111', null);
INSERT INTO creaming.members (member_id, created_date, last_modified_date, address, name, phone_number, zone_code, email, kakao_id, nickname, phone, profile_image) VALUES (25, '2021-05-20 14:29:34', '2021-05-20 14:29:34', null, null, null, null, 'ekdbs628@daum.net', '1729295889', '커피조아', '010-5164-8532', null);