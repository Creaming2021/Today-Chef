create table product_review_file
(
    file_id           bigint not null
        primary key,
    product_review_id bigint null,
    constraint FKc9ldc6f89eyrfqtjhptmsulg0
        foreign key (file_id) references file (file_id),
    constraint FKqf04eaxvq3lcd4svqwvlullww
        foreign key (product_review_id) references product_reviews (product_review_id)
);

