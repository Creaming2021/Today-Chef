create table cart
(
    cart_id    bigint auto_increment
        primary key,
    amount     int    null,
    member_id  bigint null,
    product_id bigint null,
    constraint FKpu4bcbluhsxagirmbdn7dilm5
        foreign key (product_id) references products (product_id),
    constraint FKrfk8bqyb1lyk6pp3ng7nwqwm5
        foreign key (member_id) references members (member_id)
);

