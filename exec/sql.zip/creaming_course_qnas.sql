create table course_qnas
(
    course_qna_id      bigint auto_increment
        primary key,
    created_date       datetime     null,
    last_modified_date datetime     null,
    content            longtext     null,
    is_secret          bit          null,
    title              varchar(255) null,
    course_id          bigint       null,
    member_id          bigint       null,
    constraint FKdnouxgw7j5j61d3ljggi1vfr4
        foreign key (course_id) references courses (course_id),
    constraint FKnogvmlrf6folacos55txoy08o
        foreign key (member_id) references members (member_id)
);

