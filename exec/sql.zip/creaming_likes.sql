create table likes
(
    like_id   bigint auto_increment
        primary key,
    course_id bigint null,
    member_id bigint null,
    constraint FK166rh7nhmtcajf0xo1f1i3s8p
        foreign key (member_id) references members (member_id),
    constraint FKr508bwvxlb812s6ijuo4vgoj0
        foreign key (course_id) references courses (course_id)
);

