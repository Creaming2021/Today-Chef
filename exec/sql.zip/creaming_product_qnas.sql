create table product_qnas
(
    product_qna_id     bigint auto_increment
        primary key,
    created_date       datetime     null,
    last_modified_date datetime     null,
    answer             varchar(255) null,
    answer_date        datetime     null,
    content            longtext     null,
    is_secret          bit          null,
    title              varchar(255) null,
    member_id          bigint       null,
    product_id         bigint       null,
    constraint FKehqkyyd50yn80egu6e2jj747f
        foreign key (product_id) references products (product_id),
    constraint FKgj5tn68eyne8t61buli7dxhw5
        foreign key (member_id) references members (member_id)
);

INSERT INTO creaming.product_qnas (product_qna_id, created_date, last_modified_date, answer, answer_date, content, is_secret, title, member_id, product_id) VALUES (1, '2021-05-19 00:23:19', '2021-05-19 00:23:19', '감사합니다^^', '2021-05-20 02:05:02', '# 찾아서 돈쭐내고 싶어요', false, '석관동이 어디인가여?', 8, 3);
INSERT INTO creaming.product_qnas (product_qna_id, created_date, last_modified_date, answer, answer_date, content, is_secret, title, member_id, product_id) VALUES (4, '2021-05-19 01:13:31', '2021-05-19 01:13:31', '감사합니다!!', '2021-05-20 02:05:03', '여러분 이거 꼭 사서드세요...
먹자마자 또 시켰어요..', false, '이거 완전 맛있음...', 7, 3);
INSERT INTO creaming.product_qnas (product_qna_id, created_date, last_modified_date, answer, answer_date, content, is_secret, title, member_id, product_id) VALUES (5, '2021-05-19 08:13:19', '2021-05-19 08:13:19', '', null, '있어요!!', false, '질문!!!!!', 11, 5);
INSERT INTO creaming.product_qnas (product_qna_id, created_date, last_modified_date, answer, answer_date, content, is_secret, title, member_id, product_id) VALUES (6, '2021-05-20 01:30:13', '2021-05-20 01:30:13', '', null, '정말 궁금해요', false, '궁금해요', 19, 14);
INSERT INTO creaming.product_qnas (product_qna_id, created_date, last_modified_date, answer, answer_date, content, is_secret, title, member_id, product_id) VALUES (7, '2021-05-20 02:03:29', '2021-05-20 02:03:29', '오늘 발송완료했습니다^^ 내일이나 내일모레 도착예정입니다^^', '2021-05-20 02:05:04', '내일 일이 있어서 받아봐야합니다ㅜ', false, '언제쯤 배송될까요?', 15, 20);