create table course_review_file
(
    file_id          bigint not null
        primary key,
    course_review_id bigint null,
    constraint FK3p36o0auowu7hany75wviq74g
        foreign key (file_id) references file (file_id),
    constraint FKmxspl8jrse9f9d1j08vpfl0ei
        foreign key (course_review_id) references course_reviews (course_review_id)
);

