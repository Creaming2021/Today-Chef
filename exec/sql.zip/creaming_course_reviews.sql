create table course_reviews
(
    course_review_id   bigint auto_increment
        primary key,
    created_date       datetime     null,
    last_modified_date datetime     null,
    content            longtext     null,
    rating             int          null,
    title              varchar(255) null,
    course_id          bigint       null,
    member_id          bigint       null,
    constraint FK799g8dfcye3g51ru63bfdhyb1
        foreign key (course_id) references courses (course_id),
    constraint FKlrpaadw9mi16mpm88uum9bdhm
        foreign key (member_id) references members (member_id)
);

