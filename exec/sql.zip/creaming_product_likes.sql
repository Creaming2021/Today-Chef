create table product_likes
(
    product_like_id bigint auto_increment
        primary key,
    member_id       bigint null,
    product_id      bigint null,
    constraint FK795q9hiytbh68mn8om6hmxpoa
        foreign key (product_id) references products (product_id),
    constraint FKfuy8kqa7na7i2tyysqrxo8rs7
        foreign key (member_id) references members (member_id)
);

