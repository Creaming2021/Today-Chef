create table course_room
(
    room_id   bigint not null
        primary key,
    course_id bigint null,
    constraint FK16b93ghxaidua4mhexwgktrx2
        foreign key (room_id) references room (room_id),
    constraint FKdyt03ca2c6ibqjtieoytt4oth
        foreign key (course_id) references courses (course_id)
);

INSERT INTO creaming.course_room (room_id, course_id) VALUES (12, 12);
INSERT INTO creaming.course_room (room_id, course_id) VALUES (13, 13);
INSERT INTO creaming.course_room (room_id, course_id) VALUES (15, 15);
INSERT INTO creaming.course_room (room_id, course_id) VALUES (16, 16);
INSERT INTO creaming.course_room (room_id, course_id) VALUES (18, 18);
INSERT INTO creaming.course_room (room_id, course_id) VALUES (23, 23);