create table qna_comment
(
    comment_id    bigint not null
        primary key,
    course_qna_id bigint null,
    constraint FK6wjdy6pscd140bxpm1xj068wk
        foreign key (course_qna_id) references course_qnas (course_qna_id),
    constraint FKmeeka8uwvhovqos6iabosl18s
        foreign key (comment_id) references comment (comment_id)
);

