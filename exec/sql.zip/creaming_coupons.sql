create table coupons
(
    coupon_id          bigint auto_increment
        primary key,
    created_date       datetime     null,
    last_modified_date datetime     null,
    content            varchar(255) null,
    discount           int          null,
    expired_day        bigint       null,
    name               varchar(255) null
);

INSERT INTO creaming.coupons (coupon_id, created_date, last_modified_date, content, discount, expired_day, name) VALUES (1, '2021-05-18 06:39:20', '2021-05-18 06:39:20', '오늘 셰프에 첫 방문해주셔서 감사합니다 ', 10, 30, '회원 가입 축하 쿠폰 ❤');