create table kakaopay
(
    kakaopay_id bigint auto_increment
        primary key,
    amount      int          not null,
    created_at  datetime     null,
    tid         varchar(255) null,
    url         varchar(255) null
);

INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (1, 0, null, null, '/kakao-pay');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (2, 0, null, null, '/kakao-pay');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (3, 1, '2021-05-18 18:39:34', 'T2897721552067594693', 'https://mockup-pg-web.kakao.com/v1/d363bf198e9d248a993e1ae7688257a086981ba1c0ad98c373074aa10d3631e2/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (4, 1, '2021-05-18 18:41:22', 'T2897722015924062663', 'https://mockup-pg-web.kakao.com/v1/d0d2c28ded62fdd4ad140e36c4b49118c8c0769b87c5068595715e31b824df3b/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (5, 49500, '2021-05-19 00:42:30', 'T2897815079275432637', 'https://mockup-pg-web.kakao.com/v1/24d9fcc6c1611d9dcecee0a0bb37271a0eff41f232721749bdfdcee770a6fe02/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (6, 50000, '2021-05-19 01:48:25', 'T2897832065871088329', 'https://mockup-pg-web.kakao.com/v1/3d7d172076faf95afce8258203d9148c6925a9f03d572e60f3587734a9f5471f/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (7, 50000, '2021-05-19 01:51:41', 'T2897832907684678347', 'https://mockup-pg-web.kakao.com/v1/ad2365fd4a4c5c98fb8373a8fd9c71101c441329c9160ba515b1712043baf3ea/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (8, 50000, '2021-05-19 02:05:03', 'T2897836352248449741', 'https://mockup-pg-web.kakao.com/v1/3b9766a8fce508360d72643bb2acda1dff53487fbfe5f17527ac18e1dc7fd631/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (9, 50000, '2021-05-19 02:09:32', 'T2897837507594652367', 'https://mockup-pg-web.kakao.com/v1/d52667541d49e480580ac0b4ec7e1f41d915e8f85bcf46bf45eb341219b855b2/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (10, 50000, '2021-05-19 02:17:41', 'T2897839607833742523', 'https://mockup-pg-web.kakao.com/v1/5cb99d3118455e6ff6587baac24631a9934f0d55815b2a555c1bb3a813055f3d/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (11, 50000, '2021-05-19 08:12:42', 'T2898070251872505213', 'https://mockup-pg-web.kakao.com/v1/b6208a0c8c6919584f93c724695c9d6189acf45c93752290236b33fa7a3e1714/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (12, 8900, '2021-05-20 01:55:00', 'T2898204847557627367', 'https://mockup-pg-web.kakao.com/v1/db6207cc5bb6b035f330b40d8b62f20399ad5d5d994f8635e680fa41a3fbe46c/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (13, 9810, '2021-05-20 03:54:14', 'T2898235573753580513', 'https://mockup-pg-web.kakao.com/v1/6442e7427228b32c2e8e440ddf084443e0feac3fdb1045b91ffdd4d62f13ab6e/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (14, 20000, '2021-05-20 06:16:01', 'T2898272111040450047', 'https://mockup-pg-web.kakao.com/v1/22687e85dd117a1d05879d863cdaf786ccd419b918288c74cf186cc28cb9b1e4/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (15, 20000, '2021-05-20 06:17:36', 'T2898272519062260707', 'https://mockup-pg-web.kakao.com/v1/d5e6c74ec5bec589e15219e10909340dacc9894347b6705f041b73319c708378/info');
INSERT INTO creaming.kakaopay (kakaopay_id, amount, created_at, tid, url) VALUES (16, 30000, '2021-05-20 20:53:50', 'T2898498322672964609', 'https://mockup-pg-web.kakao.com/v1/27103683fabcb85221d5ec4edfb72f4767a08130f7acca4791ba088b7c4e8465/info');