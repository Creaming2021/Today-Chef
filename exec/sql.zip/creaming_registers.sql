create table registers
(
    register_id        bigint auto_increment
        primary key,
    created_date       datetime null,
    last_modified_date datetime null,
    price              int      not null,
    course_id          bigint   null,
    member_id          bigint   null,
    constraint FK5bv2p0h9ivo6097g16qs61vb4
        foreign key (member_id) references members (member_id),
    constraint FKpmbf0fug0pk7wb7wpi3bf8ako
        foreign key (course_id) references courses (course_id)
);

INSERT INTO creaming.registers (register_id, created_date, last_modified_date, price, course_id, member_id) VALUES (5, '2021-05-20 06:18:04', '2021-05-20 06:18:04', 20000, 16, 23);
INSERT INTO creaming.registers (register_id, created_date, last_modified_date, price, course_id, member_id) VALUES (6, '2021-05-20 20:54:21', '2021-05-20 20:54:21', 30000, 23, 24);