create table delivery
(
    delivery_id        bigint auto_increment
        primary key,
    created_date       datetime     null,
    last_modified_date datetime     null,
    address            varchar(255) null,
    name               varchar(255) null,
    phone_number       varchar(255) null,
    zone_code          varchar(255) null,
    company            varchar(255) null,
    notes              varchar(255) null,
    number             varchar(255) null,
    order_id           bigint       null,
    constraint FKu4e8rjwmg09vmas3ccjwglso
        foreign key (order_id) references orders (order_id)
);

INSERT INTO creaming.delivery (delivery_id, created_date, last_modified_date, address, name, phone_number, zone_code, company, notes, number, order_id) VALUES (1, '2021-05-19 00:43:01', '2021-05-19 00:43:01', '대구 동구 둔산로 263', '나', '0112-444', '41057', 'kr.cjlogistics', '경비실', '385025557902', 1);
INSERT INTO creaming.delivery (delivery_id, created_date, last_modified_date, address, name, phone_number, zone_code, company, notes, number, order_id) VALUES (2, '2021-05-20 03:54:34', '2021-05-20 03:54:34', '충북 청주시 청원구 공항로 89', '성진옥', '010-1234-5678', '28351', 'kr.cjlogistics', '문앞에 두고 가주세요.', '385025557902', 2);