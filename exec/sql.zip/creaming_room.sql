create table room
(
    dtype   varchar(31)  not null,
    room_id bigint auto_increment
        primary key,
    token   varchar(255) null
);

INSERT INTO creaming.room (dtype, room_id, token) VALUES ('CourseRoom', 1, 'Oiofflj84HSpsGVGQm6jepB4MNhxj7GK8zd6ke1Y');
INSERT INTO creaming.room (dtype, room_id, token) VALUES ('CourseRoom', 2, 'FOvwtD6aPgTE0I6UPgXXnTNudm0utnjq3HpTmU7t');
INSERT INTO creaming.room (dtype, room_id, token) VALUES ('CourseRoom', 3, '1KRlMcqkeAhbc2MMHAOhxXyDxTCC8McmqqsOJopq');
INSERT INTO creaming.room (dtype, room_id, token) VALUES ('CourseRoom', 12, 'PN2JLGRoMkno6t4Ms3cOqNovOnDc18SFnqDk1CqU');
INSERT INTO creaming.room (dtype, room_id, token) VALUES ('CourseRoom', 13, 'JJA7Nc8vK1w92HaTkmXDoeeTxrIZT7gZJHiI1asZ');
INSERT INTO creaming.room (dtype, room_id, token) VALUES ('CourseRoom', 15, 'HJqo8xW0HEmJi7IDoF86xE5p1VLWcPIRuRbOe0R4');
INSERT INTO creaming.room (dtype, room_id, token) VALUES ('CourseRoom', 16, 'G1t2JAPH8x7yBdOqg3mATA4LaE8RAAj6VysiVXPF');
INSERT INTO creaming.room (dtype, room_id, token) VALUES ('CourseRoom', 18, 'B8OrsNnYHY4yBX9B9qJmOhWHTUBHmC0dfl9GR49s');
INSERT INTO creaming.room (dtype, room_id, token) VALUES ('CourseRoom', 23, 's3pNyQfnzPnedFxaSm4lHJjQ1EZzEcizWVnd9X3R');