create table course_file
(
    file_id   bigint not null
        primary key,
    course_id bigint null,
    constraint FKahstwyjkn1m3rcpp9eae2kivw
        foreign key (file_id) references file (file_id),
    constraint FKhe9vff239efftdqjf2htw865u
        foreign key (course_id) references courses (course_id)
);

INSERT INTO creaming.course_file (file_id, course_id) VALUES (178, 12);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (179, 12);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (180, 12);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (181, 12);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (182, 13);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (183, 13);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (184, 13);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (185, 13);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (196, 15);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (197, 15);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (198, 15);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (199, 15);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (200, 15);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (201, 16);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (202, 16);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (203, 16);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (204, 16);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (205, 18);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (206, 18);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (207, 18);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (208, 18);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (230, 23);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (231, 23);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (232, 23);
INSERT INTO creaming.course_file (file_id, course_id) VALUES (233, 23);