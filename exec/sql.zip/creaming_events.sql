create table events
(
    event_id           bigint auto_increment
        primary key,
    created_date       datetime     null,
    last_modified_date datetime     null,
    content            longtext     null,
    image              varchar(255) null,
    title              varchar(255) null
);

INSERT INTO creaming.events (event_id, created_date, last_modified_date, content, image, title) VALUES (1, '2021-05-19 00:17:16', '2021-05-19 00:18:55', '오늘 셰프 오픈 이벤트! 신규 회원 가입 시 발급일 기준 30일간 사용 가능한 10% 할인 쿠폰 증정!', 'https://d6sx5vd3amky9.cloudfront.net/20210519001854647_event (4).png', '[이벤트] 신규 회원 가입 시 10% 할인 쿠폰 증정');
INSERT INTO creaming.events (event_id, created_date, last_modified_date, content, image, title) VALUES (2, '2021-05-19 00:18:32', '2021-05-19 00:19:02', '오늘 셰프 오픈 이벤트! 밀키트 구입 시 선착순 1000명 한정 오늘 셰프 그립톡 증정', 'https://d6sx5vd3amky9.cloudfront.net/20210519001902071_event (3).png', '[이벤트] 밀키트 구입 시 오늘 셰프 그립톡 무료 발송');
INSERT INTO creaming.events (event_id, created_date, last_modified_date, content, image, title) VALUES (3, '2021-05-20 00:10:22', '2021-05-20 20:39:33', '오늘 셰프 AR APP을 설치하시면 밀키트에 동봉되는 설명서의 영상을 재생하거나, 필요한 재료 도구를 보실 수 있습니다.', 'https://d6sx5vd3amky9.cloudfront.net/20210520203933413_event_대지 1 사본 5.png', '[APP] 오늘 셰프 AR APP 출시');