create table review_comment
(
    comment_id       bigint not null
        primary key,
    course_review_id bigint null,
    constraint FKi8plu0hb0axpjw63cv7oxj0li
        foreign key (course_review_id) references course_reviews (course_review_id),
    constraint FKpljpgtuaj54qaod48639ekslo
        foreign key (comment_id) references comment (comment_id)
);

