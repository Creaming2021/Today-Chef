create table order_detail
(
    order_detail_id bigint auto_increment
        primary key,
    amount          int    null,
    price           int    null,
    order_id        bigint null,
    product_id      bigint null,
    constraint FKc7q42e9tu0hslx6w4wxgomhvn
        foreign key (product_id) references products (product_id),
    constraint FKrws2q0si6oyd6il8gqe2aennc
        foreign key (order_id) references orders (order_id)
);

INSERT INTO creaming.order_detail (order_detail_id, amount, price, order_id, product_id) VALUES (1, 5, 49500, 1, 5);
INSERT INTO creaming.order_detail (order_detail_id, amount, price, order_id, product_id) VALUES (2, 1, 10900, 2, 38);