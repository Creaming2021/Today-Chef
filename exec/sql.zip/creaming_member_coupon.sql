create table member_coupon
(
    member_coupon_id   bigint auto_increment
        primary key,
    created_date       datetime     null,
    last_modified_date datetime     null,
    coupon_status      varchar(255) null,
    expired_date       datetime     null,
    coupon_id          bigint       null,
    member_id          bigint       null,
    constraint FKnpxy2p3rh02lyotq1g77bqcm9
        foreign key (member_id) references members (member_id),
    constraint FKtewggiiwwuchvax1bojwtcl3k
        foreign key (coupon_id) references coupons (coupon_id)
);

INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (7, '2021-05-18 07:46:34', '2021-05-18 07:46:34', 'AVAILABLE', '2021-06-17 07:46:34', 1, 6);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (8, '2021-05-18 07:47:02', '2021-05-18 07:47:02', 'AVAILABLE', '2021-06-17 07:47:02', 1, 7);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (9, '2021-05-18 07:49:34', '2021-05-18 07:49:34', 'AVAILABLE', '2021-06-17 07:49:34', 1, 8);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (10, '2021-05-19 01:28:23', '2021-05-19 01:28:23', 'AVAILABLE', '2021-06-18 01:28:23', 1, 9);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (11, '2021-05-19 01:31:19', '2021-05-20 03:54:34', 'USED', '2021-06-18 01:31:19', 1, 10);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (12, '2021-05-19 08:09:22', '2021-05-19 08:09:22', 'AVAILABLE', '2021-06-18 08:09:22', 1, 11);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (13, '2021-05-19 18:08:30', '2021-05-19 18:08:30', 'AVAILABLE', '2021-06-18 18:08:30', 1, 12);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (14, '2021-05-19 18:10:45', '2021-05-19 18:10:45', 'AVAILABLE', '2021-06-18 18:10:45', 1, 13);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (15, '2021-05-19 18:13:22', '2021-05-19 18:13:22', 'AVAILABLE', '2021-06-18 18:13:22', 1, 14);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (16, '2021-05-19 18:21:55', '2021-05-19 18:21:55', 'AVAILABLE', '2021-06-18 18:21:55', 1, 16);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (17, '2021-05-19 18:32:41', '2021-05-19 18:32:41', 'AVAILABLE', '2021-06-18 18:32:41', 1, 17);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (19, '2021-05-20 01:18:24', '2021-05-20 01:18:24', 'AVAILABLE', '2021-06-19 01:18:24', 1, 19);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (20, '2021-05-20 06:05:47', '2021-05-20 06:05:47', 'AVAILABLE', '2021-06-19 06:05:47', 1, 22);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (21, '2021-05-20 06:15:45', '2021-05-20 06:15:45', 'AVAILABLE', '2021-06-19 06:15:45', 1, 23);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (22, '2021-05-20 11:09:27', '2021-05-20 11:09:27', 'AVAILABLE', '2021-06-19 11:09:27', 1, 24);
INSERT INTO creaming.member_coupon (member_coupon_id, created_date, last_modified_date, coupon_status, expired_date, coupon_id, member_id) VALUES (23, '2021-05-20 14:29:34', '2021-05-20 14:29:34', 'AVAILABLE', '2021-06-19 14:29:34', 1, 25);