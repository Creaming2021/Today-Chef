create table orders
(
    order_id    bigint auto_increment
        primary key,
    date        datetime null,
    total_price int      null,
    member_id   bigint   null,
    constraint FK2vq7lo4gkknrmghj3rqpqqg6s
        foreign key (member_id) references members (member_id)
);

INSERT INTO creaming.orders (order_id, date, total_price, member_id) VALUES (1, '2021-05-19 00:43:01', 49500, 8);
INSERT INTO creaming.orders (order_id, date, total_price, member_id) VALUES (2, '2021-05-20 03:54:34', 9810, 10);